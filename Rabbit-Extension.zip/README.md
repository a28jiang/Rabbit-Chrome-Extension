# Rabbit-Chrome-Extension

## About

This chrome extension utilizes the chrome storage api to catalogue tab objects. User activity is stored such that a procrastination index may be calculated. This index is used to generate a cute rabbit, indicating your productivity levels.

## Credit

Thank you to [Quan](https://quan-inc.jp/en/characters/usagyuuun/) for Usagyuuun character design.

![Image of Usagyuun](https://quan-inc.jp/admin/wp-content/uploads/2018/09/dbd71ea91c853534b3183c7345c08162-300x300.png)
